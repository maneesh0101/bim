export * from './my-automation.component';
