import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'video-guidelines-widget',
  templateUrl: './video-guidelines-widget.component.html',
})
export class VideoGuidelinesWidgetComponent implements OnInit {
  constructor() {  }

  ngOnInit() {

  }

}
