import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'products-widget',
  templateUrl: './products-widget.component.html',
})
export class ProductsWidgetComponent implements OnInit {
  constructor() {  }

  ngOnInit() {

  }

}
