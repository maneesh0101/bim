import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'market-place-widget',
  templateUrl: './market-place-widget.component.html',
})
export class MarketPlaceWidgetComponent implements OnInit {
  constructor() {  }

  ngOnInit() {

  }

}
