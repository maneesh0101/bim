import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'build-solution-widget',
  templateUrl: './build-solution-widget.component.html',
})
export class BuildSolutionWidgetComponent implements OnInit {
  constructor() {  }

  ngOnInit() {
  }

}
