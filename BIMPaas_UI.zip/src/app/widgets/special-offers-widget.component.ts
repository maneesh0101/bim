import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'special-offers-widget',
  templateUrl: './special-offers-widget.component.html',
})
export class SpecialOffersWidgetComponent implements OnInit {

  constructor() {  }

  ngOnInit() {

  }

}
