export class State {
  constructor(public countryid: any, public name: string, public abbr: string) { }
}
