export class Link {
    id: number;
    source: number;
    target: number;
    type: string;
}