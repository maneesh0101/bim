export class Country {
  constructor(public id: string, public name: string) { }
}
