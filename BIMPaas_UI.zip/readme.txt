Installed package
	i). Gantt chart
		npm install dhtmlx-gantt --save
		npm install @types/dhtmlxgantt --save

	ii). Highchart
		npm install highcharts --save
	
	iii). Dashboard
		npm i angular2-datatable --save
		npm install highcharts-more --save  
		npm i ng2-inline-editor --save
		npm i highcharts-more-node

	iv). Sun Burst Chart
		npm install ngx-nvd3

	v). ng2-charts
		npm install ng4-charts --save
		npm install chart.js --save
